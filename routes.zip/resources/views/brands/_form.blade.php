<div class="mb-3">
    <label class="form-label">Nama Brand</label>
    <input
        type="text"
        name="name"
        class="form-control"
        value="{{ old('name', $brand->name ?? '') }}"
        required
    >
</div>

<div class="mb-3">
    <label class="form-label">NPWP</label>
    <input
        type="text"
        name="npwp"
        class="form-control"
        value="{{ old('npwp', $brand->npwp ?? '') }}"
    >
</div>

<div class="mb-3">
    <label class="form-label">Alamat</label>
    <textarea
        name="address"
        class="form-control"
        rows="4"
    >{{ old('address', $brand->address ?? '') }}</textarea>
</div>

<div class="mb-3">
    <label class="form-label">Telepon</label>
    <input
        type="text"
        name="phone"
        class="form-control"
        value="{{ old('phone', $brand->phone ?? '') }}"
    >
</div>

<div class="mb-3">
    <label class="form-label">Email</label>
    <input
        type="email"
        name="email"
        class="form-control"
        value="{{ old('email', $brand->email ?? '') }}"
    >
</div>

<div class="mb-3">
    <label class="form-label">Website</label>
    <input
        type="text"
        name="website"
        class="form-control"
        value="{{ old('website', $brand->website ?? '') }}"
    >
</div>

<button class="btn btn-primary">
    Simpan
</button>