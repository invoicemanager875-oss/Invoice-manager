<h1>Daftar Brand</h1>

<a href="{{ route('brands.create') }}">
    Tambah Brand
</a>

@if(session('success'))
    <p>{{ session('success') }}</p>
@endif

<table border="1" cellpadding="10">

    <thead>
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Telepon</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>

    @forelse($brands as $brand)

        <tr>

            <td>{{ $brand->name }}</td>

            <td>{{ $brand->email }}</td>

            <td>{{ $brand->phone }}</td>

            <td>

                <a href="{{ route('brands.edit',$brand) }}">
                    Edit
                </a>

                <form
                    action="{{ route('brands.destroy',$brand) }}"
                    method="POST"
                    style="display:inline;"
                >

                    @csrf
                    @method('DELETE')

                    <button>
                        Hapus
                    </button>

                </form>

            </td>

        </tr>

    @empty

        <tr>
            <td colspan="4">
                Belum ada data.
            </td>
        </tr>

    @endforelse

    </tbody>

</table>

{{ $brands->links() }}