<h1>Edit Brand</h1>

<form
    action="{{ route('brands.update', $brand) }}"
    method="POST"
>
    @csrf
    @method('PUT')

    @include('brands._form')

</form>