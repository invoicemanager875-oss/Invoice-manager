<h1>Tambah Brand</h1>

<form action="{{ route('brands.store') }}" method="POST">
    @csrf

    @include('brands._form')

</form>