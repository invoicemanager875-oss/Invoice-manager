<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Brand extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name',
        'npwp',
        'address',
        'phone',
        'email',
        'website',
        'logo_path',
        'qris_path',
        'ttd_path',
        'stempel_path',
        'materai_path',
        'ttd_nama',
        'ttd_jabatan',
        'color_header',
        'color_accent',
        'canva_link',
    ];

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class)
            ->withPivot('is_primary')
            ->withTimestamps();
    }
}