<h1>Daftar Brand</h1>

<a href="<?php echo e(route('brands.create')); ?>">
    Tambah Brand
</a>

<?php if(session('success')): ?>
    <p><?php echo e(session('success')); ?></p>
<?php endif; ?>

<table border="1" cellpadding="10">

    <thead>
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Telepon</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

            <td><?php echo e($brand->name); ?></td>

            <td><?php echo e($brand->email); ?></td>

            <td><?php echo e($brand->phone); ?></td>

            <td>

                <a href="<?php echo e(route('brands.edit',$brand)); ?>">
                    Edit
                </a>

                <form
                    action="<?php echo e(route('brands.destroy',$brand)); ?>"
                    method="POST"
                    style="display:inline;"
                >

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button>
                        Hapus
                    </button>

                </form>

            </td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>
            <td colspan="4">
                Belum ada data.
            </td>
        </tr>

    <?php endif; ?>

    </tbody>

</table>

<?php echo e($brands->links()); ?><?php /**PATH D:\$Project\Invoice-project\invoice-manager\resources\views/brands/index.blade.php ENDPATH**/ ?>