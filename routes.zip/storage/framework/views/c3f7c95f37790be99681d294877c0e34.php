<h1>Tambah Brand</h1>

<form action="<?php echo e(route('brands.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <?php echo $__env->make('brands._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</form><?php /**PATH D:\$Project\Invoice-project\invoice-manager\resources\views/brands/create.blade.php ENDPATH**/ ?>