<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between flex-wrap gap-3">
            <div>
                <h2 class="text-xl font-bold text-navy-600">Dashboard</h2>
                <p class="text-sm text-slate-500 mt-0.5">
                    Selamat datang, <?php echo e(auth()->user()->name); ?>

                    <?php if(!$isAdmin): ?> &middot; <?php echo e($brandCount); ?> brand Anda kelola <?php endif; ?>
                </p>
            </div>

            <?php if(\Illuminate\Support\Facades\Route::has('invoices.create')): ?>
                <a href="<?php echo e(route('invoices.create')); ?>"
                   class="inline-flex items-center gap-2 bg-gold-400 hover:bg-gold-500 text-navy-700 text-sm font-bold px-4 py-2 rounded-lg transition">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus-circle','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus-circle','class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    Buat Invoice
                </a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">

        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-white rounded-xl border border-slate-200 p-4">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Total Invoice</div>
                <div class="text-2xl font-bold text-navy-600 mt-1"><?php echo e($stats['total_invoice']); ?></div>
            </div>
            <div class="bg-white rounded-xl border border-slate-200 p-4">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Lunas</div>
                <div class="text-2xl font-bold text-emerald-600 mt-1"><?php echo e($stats['lunas']); ?></div>
            </div>
            <div class="bg-white rounded-xl border border-slate-200 p-4">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Menunggu</div>
                <div class="text-2xl font-bold text-amber-500 mt-1"><?php echo e($stats['menunggu']); ?></div>
            </div>
            <div class="bg-white rounded-xl border border-slate-200 p-4">
                <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Total Pendapatan</div>
                <div class="text-lg font-bold text-navy-600 mt-1">
                    Rp <?php echo e(number_format($stats['pendapatan'], 0, ',', '.')); ?>

                </div>
            </div>
        </div>

        <?php if(!\Illuminate\Support\Facades\Schema::hasTable('invoices')): ?>
            <div class="rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-sm px-4 py-3">
                💡 Modul Invoice belum dibangun &mdash; angka di atas masih placeholder (Fase 0: Auth &amp; Brand sudah aktif).
                Anda mengelola <strong><?php echo e($brandCount); ?></strong> brand saat ini.
            </div>
        <?php endif; ?>

        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div class="bg-white rounded-xl border border-slate-200">
                <div class="px-5 py-3 border-b border-slate-100 text-sm font-semibold text-navy-600">
                    Pendapatan per Brand
                </div>
                <div class="p-5">
                    <?php if($brandCount): ?>
                        <div class="flex items-end justify-around gap-2 h-40 border-l-2 border-b-2 border-slate-100 px-2">
                            <?php $__currentLoopData = range(1, min($brandCount, 6)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-col items-center gap-1 flex-1">
                                    <div class="w-full max-w-8 bg-navy-600 rounded-t" style="height:<?php echo e(rand(20, 130)); ?>px"></div>
                                    <span class="text-[9px] text-slate-400">B<?php echo e($i); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-slate-400 text-center py-14">Belum ada data</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="bg-white rounded-xl border border-slate-200">
                <div class="px-5 py-3 border-b border-slate-100 text-sm font-semibold text-navy-600">
                    Pendapatan Bulanan
                </div>
                <div class="p-5">
                    <div class="flex items-end justify-around gap-1 h-40 border-l-2 border-b-2 border-slate-100 px-2">
                        <?php $__currentLoopData = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-col items-center gap-1 flex-1">
                                <div class="w-full max-w-5 bg-gold-400 rounded-t" style="height:<?php echo e(max(2, $monthlyRevenue[$i])); ?>px"></div>
                                <span class="text-[8px] text-slate-400"><?php echo e($m); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div class="px-5 py-3 border-b border-slate-100 text-sm font-semibold text-navy-600">
                Invoice Terbaru
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-slate-50 text-[11px] uppercase tracking-wide text-slate-500">
                            <th class="text-left px-5 py-2.5">No.</th>
                            <th class="text-left px-5 py-2.5">Brand</th>
                            <th class="text-left px-5 py-2.5">Klien</th>
                            <th class="text-left px-5 py-2.5">Total</th>
                            <th class="text-left px-5 py-2.5">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $recentInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-5 py-2.5 font-semibold text-navy-600"><?php echo e($inv->nomor); ?></td>
                                <td class="px-5 py-2.5"><?php echo e($inv->brand->name ?? '-'); ?></td>
                                <td class="px-5 py-2.5"><?php echo e($inv->klien); ?></td>
                                <td class="px-5 py-2.5 font-medium">Rp <?php echo e(number_format($inv->total, 0, ',', '.')); ?></td>
                                <td class="px-5 py-2.5">
                                    <span class="text-xs font-semibold px-2.5 py-1 rounded-full
                                        <?php echo e($inv->status === 'lunas' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'); ?>">
                                        <?php echo e(ucfirst($inv->status)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-10 text-slate-400">Belum ada invoice</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\$Project\Invoice-project\invoice-manager\resources\views/dashboard.blade.php ENDPATH**/ ?>